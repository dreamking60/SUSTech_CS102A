package xyz.chengzi.halma.model;

import xyz.chengzi.halma.controller.GameController;
import xyz.chengzi.halma.listener.GameListener;
import xyz.chengzi.halma.listener.Listenable;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ChessBoard implements Listenable<GameListener> {
    private List<GameListener> listenerList = new ArrayList<>();
    private Square[][] grid;
    private int dimension;
    private ArrayList<ChessBoardLocation> location=new ArrayList<>();
    public ChessBoard(int dimension) {
        this.grid = new Square[dimension][dimension];
        this.dimension = dimension;
        initGrid();
    }

    private void initGrid() {
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                grid[i][j] = new Square(new ChessBoardLocation(i, j));
            }
        }
    }
    public void placeInitialPieces() {
        grid[0][0].setPiece(new ChessPiece(Color.RED));
        grid[0][1].setPiece(new ChessPiece(Color.RED));
        grid[1][0].setPiece(new ChessPiece(Color.RED));
        grid[1][1].setPiece(new ChessPiece(Color.RED));
        grid[0][2].setPiece(new ChessPiece(Color.RED));
        grid[2][0].setPiece(new ChessPiece(Color.RED));
        grid[3][0].setPiece(new ChessPiece(Color.RED));
        grid[0][3].setPiece(new ChessPiece(Color.RED));
        grid[2][1].setPiece(new ChessPiece(Color.RED));
        grid[1][2].setPiece(new ChessPiece(Color.RED));
        grid[0][4].setPiece(new ChessPiece(Color.RED));
        grid[4][0].setPiece(new ChessPiece(Color.RED));
        grid[3][1].setPiece(new ChessPiece(Color.RED));
        grid[1][3].setPiece(new ChessPiece(Color.RED));
        grid[2][2].setPiece(new ChessPiece(Color.RED));
        grid[4][1].setPiece(new ChessPiece(Color.RED));
        grid[1][4].setPiece(new ChessPiece(Color.RED));
        grid[3][2].setPiece(new ChessPiece(Color.RED));
        grid[2][3].setPiece(new ChessPiece(Color.RED));
        grid[dimension - 1][dimension - 1].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 1][dimension - 2].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 2][dimension - 1].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 2][dimension - 2].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 1][dimension - 3].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 3][dimension - 1].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 4][dimension - 1].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 1][dimension - 4].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 2][dimension - 3].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 3][dimension - 2].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 1][dimension - 5].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 5][dimension - 1].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 2][dimension - 4].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 4][dimension - 2].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 2][dimension - 5].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 5][dimension - 2].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 3][dimension - 3].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 3][dimension - 4].setPiece(new ChessPiece(Color.GREEN));
        grid[dimension - 4][dimension - 3].setPiece(new ChessPiece(Color.GREEN));
        listenerList.forEach(listener -> listener.onChessBoardReload(this));
    }

    public Square getGridAt(ChessBoardLocation location) {
        return grid[location.getRow()][location.getColumn()];
    }

    public ChessPiece getChessPieceAt(ChessBoardLocation location) {
        return getGridAt(location).getPiece();
    }

    public void setChessPieceAt(ChessBoardLocation location, ChessPiece piece) {
        getGridAt(location).setPiece(piece);
        listenerList.forEach(listener -> listener.onChessPiecePlace(location, piece));
    }

    public ChessPiece removeChessPieceAt(ChessBoardLocation location) {
        ChessPiece piece = getGridAt(location).getPiece();
        getGridAt(location).setPiece(null);
        listenerList.forEach(listener -> listener.onChessPieceRemove(location));
        return piece;
    }

    public void moveChessPiece(ChessBoardLocation src, ChessBoardLocation dest) {
        if (!(isValidMove1(src, dest)||isValidMove2(src, dest))) {
            throw new IllegalArgumentException("Illegal halma move");
        }
        setChessPieceAt(dest, removeChessPieceAt(src));
    }
    public int getDimension() {
        return dimension;
    }
    public ArrayList<ChessBoardLocation> library(ChessBoardLocation src){
        ArrayList<ChessBoardLocation>a=new ArrayList<>();
        ArrayList<ChessBoardLocation>b=new ArrayList<>();
        a.add(src);
        for (int i=0;i<16;i++){
            for (int j=0;j<16;j++){
                for (ChessBoardLocation chessBoardLocation : a) {
                    if (isVaild(chessBoardLocation, new ChessBoardLocation(i, j))) {
                        b.add(new ChessBoardLocation(i, j));
                    }
                }
            }
        }
        ArrayList<ChessBoardLocation>c= new ArrayList<>();
        while (!b.equals(c)) {
            a.addAll(b);
            b = new ArrayList<>();
            for (int i = 0; i < 16; i++) {
                for (int j = 0; j < 16; j++) {
                    for (ChessBoardLocation chessBoardLocation : a) {
                        if (isVaild2(chessBoardLocation, new ChessBoardLocation(i, j))&&!a.contains(new ChessBoardLocation(i,j))&&getChessPieceAt(new ChessBoardLocation(i,j))==null) {
                            b.add(new ChessBoardLocation(i, j));
                        }
                    }
                }
            }
        }
        return a;
    }
    public boolean isVaild2(ChessBoardLocation src,ChessBoardLocation dest){
        if ( getChessPieceAt(dest) != null) {
            return false;
        }
        int srcRow = src.getRow(), srcCol = src.getColumn(), destRow = dest.getRow(), destCol = dest.getColumn();
        if(srcRow >16&&srcCol>16&& destRow >16&& destCol >16){
            return false;
        }
        if(srcRow <0&&srcCol<0&& destRow <0&& destCol <0){
            return false;
        }
        int rowDistance = destRow - srcRow, colDistance = destCol - srcCol;
        if((srcRow+destRow)%2==0&&(srcCol+destCol)%2==0) {
            ChessBoardLocation middle = new ChessBoardLocation((srcRow + destRow) / 2, (srcCol + destCol) / 2);
            if (rowDistance <= 2 && colDistance <= 2) {
                if(getChessPieceAt(middle) != null){
                    return true;
                }
            }
        }
        return false;
    }
    public boolean isVaild(ChessBoardLocation src,ChessBoardLocation dest){
        if (getChessPieceAt(src) == null || getChessPieceAt(dest) != null) {
            return false;
        }
        int srcRow = src.getRow(), srcCol = src.getColumn(), destRow = dest.getRow(), destCol = dest.getColumn();
        if(srcRow >16&&srcCol>16&& destRow >16&& destCol >16){
            return false;
        }
        if(srcRow <0&&srcCol<0&& destRow <0&& destCol <0){
            return false;
        }
        int rowDistance = destRow - srcRow, colDistance = destCol - srcCol;
        if((srcRow+destRow)%2==0&&(srcCol+destCol)%2==0) {
            ChessBoardLocation middle = new ChessBoardLocation((srcRow + destRow) / 2, (srcCol + destCol) / 2);
            if (rowDistance <= 2 && colDistance <= 2) {
                if(getChessPieceAt(middle) != null){
                    return true;
                }
            }
        }
        return false;
    }
    public boolean isValidMove1(ChessBoardLocation src, ChessBoardLocation dest) {
        if (getChessPieceAt(src) == null || getChessPieceAt(dest) != null) {
            return false;
        }
        int srcRow = src.getRow(), srcCol = src.getColumn(), destRow = dest.getRow(), destCol = dest.getColumn();
        int rowDistance = destRow - srcRow, colDistance = destCol - srcCol;

        if (rowDistance != 0 && colDistance != 0 && Math.abs((double) rowDistance / colDistance) != 1.0) {
            return false;
        }
        return  Math.abs(rowDistance) <= 1 && Math.abs(colDistance) <= 1;
    }
    public boolean isValidMove2(ChessBoardLocation src, ChessBoardLocation dest) {
        if (getChessPieceAt(src) == null || getChessPieceAt(dest) != null) {
            return false;
        }
        if (src==dest){
            return false;
        }
        if (library(src).contains(dest)){
            return true;
        }
        return false;
    }
    public ArrayList<ChessBoardLocation> check(Color a){
        ArrayList<ChessBoardLocation> b=new ArrayList<>();
        for (int i=0;i<dimension;i++ ){
            for (int j=0;j<dimension;j++){
                if(getChessPieceAt(new ChessBoardLocation(i,j))!=null&&getChessPieceAt(new ChessBoardLocation(i,j)).getColor()==a){
                    b.add(new ChessBoardLocation(i,j));
                }
            }
        }
        return b;
    }
    public boolean winner(ArrayList<ChessBoardLocation> A,Color a){
        if(a==Color.GREEN){
            for (int i=0;i<5;i++){
                for (int j=0;j<5&&(i+j<6);j++){
                    if(!A.contains(new ChessBoardLocation(i,j))){
                        return false;
                    }
                }
            }
            return true;
        }
       else {
           for (int i=15;i>10;i--){
               for (int j=15;j>10&&i+j>24;j--){
                   if(!A.contains(new ChessBoardLocation(i,j))){
                       return false;
                   }
               }
           }
           return true;
        }
    }

    @Override
    public void registerListener(GameListener listener) {
        listenerList.add(listener);
    }

    @Override
    public void unregisterListener(GameListener listener) {
        listenerList.remove(listener);
    }
}