package xyz.chengzi.halma.view;

import xyz.chengzi.halma.Halma;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Rule extends JFrame {
    private JButton Return = new JButton("Return");
    private JLabel rule = new JLabel();
    private JLabel null1 = new JLabel(" ");

    public Rule(){
        GridBagLayout gr = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;
        JPanel ruleTxt = new JPanel(gr);

        rule.setText("请在这里添加规则。");

        gr.addLayoutComponent(rule, c);
        gr.addLayoutComponent(null1, c);
        gr.addLayoutComponent(Return, c);

        ruleTxt.add(rule);
        ruleTxt.add(null1);
        ruleTxt.add(Return);

        this.add(ruleTxt);
        Return.addActionListener(new ButtonControl());
    }

    public class ButtonControl implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            dispose();
            if( event.getSource().equals(Return)){
                SwingUtilities.invokeLater(() -> {
                    JFrame START = new Start();
                    START.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    START.setVisible(true);
                    START.setTitle("Halma");
                    START.setSize(600, 600);
                });
            }
        }
    }
}
