package xyz.chengzi.halma.view;

import xyz.chengzi.halma.Halma;
import xyz.chengzi.halma.controller.GameController;
import xyz.chengzi.halma.model.ChessBoard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Start extends JFrame {
    private JButton CP = new JButton("Computer Player Game");
    private JButton Player = new JButton("Player Game");
    private JButton rule = new JButton("Game Rule");
    private JLabel topic = new JLabel("Halma",JLabel.CENTER);
    private JLabel null1 = new JLabel("  ", JLabel.CENTER);
    private JLabel null2 = new JLabel("  ", JLabel.CENTER);
    private JLabel null0 = new JLabel("  ", JLabel.CENTER);

    public Start(){
        JPanel StartPanel = new JPanel();
        GridBagLayout gr = new GridBagLayout();
        GridBagConstraints c = null;
        StartPanel.setLayout(gr);

        Font font = new Font("微软雅黑",Font.BOLD,30);
        topic.setFont(font);

        c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.gridwidth = GridBagConstraints.REMAINDER;
        gr.addLayoutComponent(topic, c);

        c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;
        gr.addLayoutComponent(null0, c);

        c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.gridwidth = GridBagConstraints.REMAINDER;
        gr.addLayoutComponent(CP, c);

        c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;
        gr.addLayoutComponent(null1, c);

        c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.fill = GridBagConstraints.BOTH;
        gr.addLayoutComponent(Player,c );

        c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;
        gr.addLayoutComponent(null2, c);

        c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.fill = GridBagConstraints.BOTH;
        gr.addLayoutComponent(rule,c );

        StartPanel.add(topic);
        StartPanel.add(null0);
        StartPanel.add(CP);
        StartPanel.add(null1);
        StartPanel.add(Player);
        StartPanel.add(null2);
        StartPanel.add(rule);
        this.add(StartPanel, BorderLayout.CENTER);

        CP.addActionListener(new ButtonAction());
        Player.addActionListener(new ButtonAction());
        rule.addActionListener(new ButtonAction());
    }

    public class ButtonAction implements ActionListener{
        public void actionPerformed (ActionEvent event){
            dispose();
            if( event.getSource().equals(CP)){
                //玩家与电脑对战的窗口

            }

            if( event.getSource().equals(Player)){
                //玩家与玩家对战的窗口列表
                SwingUtilities.invokeLater(() ->{
                JFrame PlayerGame = new PlayerGame();
                PlayerGame.setVisible(true);
                PlayerGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                PlayerGame.setSize(600, 600);
                });
            }

            if( event.getSource().equals(rule)){
                //规则的窗口
                SwingUtilities.invokeLater(() ->{
                  JFrame rule = new Rule();
                  rule.setVisible(true);
                  rule.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                  rule.setSize(600,600);
                });

            }

        }
    }
}
