package xyz.chengzi.halma.controller;

import com.sun.deploy.cache.BaseLocalApplicationProperties;
import xyz.chengzi.halma.listener.InputListener;
import xyz.chengzi.halma.model.ChessBoard;
import xyz.chengzi.halma.model.ChessBoardLocation;
import xyz.chengzi.halma.model.ChessPiece;
import xyz.chengzi.halma.music;
import xyz.chengzi.halma.view.*;

import javax.swing.*;
import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;

public class GameController implements InputListener {
    private ChessBoardComponent view;
    private ChessBoard model;
    private ChessBoardLocation selectedLocation;
    public Color currentPlayer;
    private chessManual Manual;

    public GameController(ChessBoardComponent chessBoardComponent, ChessBoard chessBoard) {
        this.view = chessBoardComponent;
        this.model = chessBoard;
        this.currentPlayer = Color.RED;
        view.registerListener(this);
        model.registerListener(view);
        model.placeInitialPieces();
    }

    public void setManual(chessManual manual) {
        Manual = manual;
    }

    public chessManual getManual() {
        return Manual;
    }

    public ChessBoardLocation getSelectedLocation() {
        return selectedLocation;
    }

    public void setSelectedLocation(ChessBoardLocation location) {
        this.selectedLocation = location;
    }

    public void resetSelectedLocation() {
        setSelectedLocation(null);
    }

    public boolean hasSelectedLocation() {
        return selectedLocation != null;
    }

    public Color nextPlayer() {
        return currentPlayer = currentPlayer == Color.RED ? Color.GREEN : Color.RED;
    }

    @Override
    public void onPlayerClickSquare(ChessBoardLocation location, SquareComponent component) {
        if (hasSelectedLocation() && model.isValidMove1(getSelectedLocation(), location)) {
            model.moveChessPiece(selectedLocation, location);
            resetSelectedLocation();
            if(model.winner(model.check(Color.RED),Color.RED)){
                System.out.println("Red win");
            }
            if(model.winner(model.check(Color.GREEN),Color.GREEN)){
                System.out.println("Green win");
            }
            nextPlayer();
        }
        if (hasSelectedLocation() && model.isValidMove2(getSelectedLocation(), location)) {
            model.moveChessPiece(selectedLocation, location);
            resetSelectedLocation();
            if(model.winner(model.check(Color.RED),Color.RED)){
               System.out.println("Red win");
            }
            if(model.winner(model.check(Color.GREEN),Color.GREEN)){ System.out.println("Green win");
            }
            nextPlayer();
        }
    }

    @Override
    public void onPlayerClickChessPiece(ChessBoardLocation location, ChessComponent component) {
        ChessPiece piece = model.getChessPieceAt(location);
        if (piece.getColor() == currentPlayer && (!hasSelectedLocation() || location.equals(getSelectedLocation()))) {
            if (!hasSelectedLocation()) {
                setSelectedLocation(location);
            } else {
                resetSelectedLocation();
            }
            component.setSelected(!component.isSelected());
            component.repaint();
        }
    }

    public void regret() {
        ArrayList<Undo> a = Manual.getManual();
        ChessBoardLocation A = a.get(a.size()).getA();
        ChessBoardLocation B = a.get(a.size()).getB();
        model.moveChessPiece(A, B);
        nextPlayer();
    }

   public void Check(){

   }
}
