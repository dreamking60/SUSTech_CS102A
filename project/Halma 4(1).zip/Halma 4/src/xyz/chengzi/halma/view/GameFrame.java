package xyz.chengzi.halma.view;
import com.sun.deploy.cache.BaseLocalApplicationProperties;
import xyz.chengzi.halma.controller.GameController;
import xyz.chengzi.halma.listener.InputListener;
import xyz.chengzi.halma.model.ChessBoard;
import xyz.chengzi.halma.model.ChessBoardLocation;
import xyz.chengzi.halma.music;

import javax.swing.*;
import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;

public class GameFrame<ObjectOnputStream> extends JFrame {
    File f;
    URI uri;
    URL url;

    private JButton undo = new JButton("Undo"); //悔棋
    private JButton restart = new JButton("Restart");
    private JButton save = new JButton("Save");
    private JButton EXIT = new JButton("Exit");
    private JButton button = new JButton("music");
    private JLabel null0 = new JLabel("  ");
    private JLabel null1 = new JLabel("  ");
    private JLabel null2 = new JLabel("  ");
    private JLabel null3 = new JLabel("  ");

    private final JFrame jf = new JFrame("测试窗口");


    public GameFrame() {
        setTitle("2020 CS102A Project");
        setSize(776, 810);
        setLocationRelativeTo(null); // Center the window
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel control = new JPanel();

        JLabel statusLabel = new JLabel("Sample label");
        add(statusLabel, BorderLayout.SOUTH);

        GridBagLayout gr = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        c.gridwidth = GridBagConstraints.REMAINDER;
        c.fill = GridBagConstraints.BOTH;
        control.setLayout(gr);

        final int[] count = {0};
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ex) {
                count[0]++;
                if (count[0] == 1) {
                    try {
                        f = new File("D:\\\\music\\\\src\\\\湖心勇者.wav");
                        uri = f.toURI();
                        try {
                            url = uri.toURL();  //解析地址
                        } catch (MalformedURLException e) {
                            e.printStackTrace();
                        }
                        AudioClip aau;
                        aau = Applet.newAudioClip(url);
                        aau.loop();  //循环播放
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }


        });
        gr.addLayoutComponent(undo, c);
        gr.addLayoutComponent(null0, c);
        gr.addLayoutComponent(button,c);
        gr.addLayoutComponent(null1, c);
        gr.addLayoutComponent(save, c);
        gr.addLayoutComponent(null2, c);
        gr.addLayoutComponent(restart, c);
        gr.addLayoutComponent(null3, c);
        gr.addLayoutComponent(EXIT, c);

        control.add(undo);
        control.add(null0);
        control.add(button);
        control.add(null1);
        control.add(save);
        control.add(null2);
        control.add(restart);
        control.add(null3);
        control.add(EXIT);
        this.add(control, BorderLayout.EAST);

        undo.addActionListener(new ButtonControl());
        save.addActionListener(new ButtonControl());
        restart.addActionListener(new ButtonControl());
        EXIT.addActionListener(new ButtonControl());
    }
    public class ButtonControl implements ActionListener{
        public void actionPerformed(ActionEvent event){
            jf.setSize(400, 400);
            jf.setLocationRelativeTo(null);
            jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            if(event.getSource().equals(restart)){
                int result = JOptionPane.showConfirmDialog(
                        jf,
                        "Restart?",
                        "tip",
                        JOptionPane.YES_NO_CANCEL_OPTION
                );
                if( result == 0) {
                    dispose();
                    SwingUtilities.invokeLater(() -> {
                        ChessBoardComponent chessBoardComponent = new ChessBoardComponent(640, 16);
                        ChessBoard chessBoard = new ChessBoard(16,2);
                        GameController controller = new GameController(chessBoardComponent, chessBoard);
                        GameFrame mainFrame = new GameFrame();
                        mainFrame.add(chessBoardComponent, BorderLayout.CENTER);
                        mainFrame.setVisible(true);
                        new music();
                    });
                }
            }
            if(event.getSource().equals(save)){
                int result = JOptionPane.showConfirmDialog(
                        jf,
                        "Exit?",
                        "tip",
                        JOptionPane.YES_NO_CANCEL_OPTION
                );
            }
            if(event.getSource().equals(EXIT)){
                int result = JOptionPane.showConfirmDialog(
                        jf,
                        "Exit?",
                        "tip",
                        JOptionPane.YES_NO_CANCEL_OPTION
                );
                if( result == 0) {
                    dispose();
                    //返回主界面
                    SwingUtilities.invokeLater(() -> {
                        JFrame START = new Start();
                        START.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        START.setVisible(true);
                        START.setTitle("Halma");
                        START.setSize(600, 600);
                    });
                }
            }
            if(event.getSource().equals(undo)) {
                int result = JOptionPane.showConfirmDialog(
                        jf,
                        "undo?",
                        "tip",
                        JOptionPane.YES_NO_CANCEL_OPTION
                );
                if (result == 0){
                }
            }
        }
    }

}
