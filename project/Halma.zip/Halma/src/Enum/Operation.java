package Enum;

public enum Operation {
    Jump,Move
}
