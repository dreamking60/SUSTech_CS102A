package xyz.chengzi.halma.listener;

public interface Listener {
}
