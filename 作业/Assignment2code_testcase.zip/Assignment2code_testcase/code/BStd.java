import java.util.Scanner;

public class BStd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long a = sc.nextLong();
        long m = sc.nextLong();
        long s = sc.nextLong();
        long ans = a;
        while (s != -1) {
            long k = sc.nextLong();
            a = (a * s + k) % m;
            ans ^= a;
            s = sc.nextLong();
        }
        System.out.println(ans);
    }
}
