import java.util.Scanner;

public class XStd {
    public static void main(String[] args) {
        char[] ch = {'-', '1', '2', '3', '4', '5', '6', '7', '8'};
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        int n = sc.nextInt();
        char[][] map = new char[m][];
        for (int i = 0; i < m; i++) {
            map[i] = sc.next().toCharArray();
        }
        int[][] count = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (map[i][j] == '*') {
                    for (int di = -1; di <= 1; di++) {
                        for (int dj = -1; dj <= 1; dj++) {
                            if (i+di >= 0 && i+di < m && j+dj >= 0 && j+dj < n) {
                                count[i+di][j+dj]++;
                            }
                        }
                    }
                    count[i][j] = 9;
                }
            }
        }
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (count[i][j] >= 9) {
                    System.out.print('F');
                } else {
                    System.out.print(ch[count[i][j]]);
                }
            }
            System.out.println();
        }
    }
}
