import java.util.Scanner;

public class EStd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int m = sc.nextInt();
        int n = sc.nextInt();
        int[][] matrix = new int[m][n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = sc.nextInt();
            }
        }
        for (int t = 1; t < N; t++) {
            int mi = sc.nextInt();
            int ni = sc.nextInt();
            int[][] tmp = new int[mi][ni];
            for (int i = 0; i < mi; i++) {
                for (int j = 0; j < ni; j++) {
                    tmp[i][j] = sc.nextInt();
                }
            }
            int[][] res = new int[m][ni];
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < ni; j++) {
                    for (int k = 0; k < n; k++) {
                        res[i][j] += matrix[i][k] * tmp[k][j];
                    }
                }
            }
            n = ni;
            matrix = res;
        }
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
    }
}
