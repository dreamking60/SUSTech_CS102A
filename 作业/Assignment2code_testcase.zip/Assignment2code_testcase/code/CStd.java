import java.util.Scanner;

public class CStd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char[] digits = sc.next().toCharArray();
        int[] count = new int[10];
        for (char d : digits) {
            count[d-'0']++;
        }
        for (int i = 0; i < 10; i++) {
            System.out.print(count[i] + " ");
        }
        System.out.println();
    }
} 
